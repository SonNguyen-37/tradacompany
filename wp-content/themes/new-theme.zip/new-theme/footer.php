<div class="mui-row" id="footer">
            <div class="mui-col-md-10 mui-col-md-offset-1" style="background-color: aqua;">
                <div class="mui-row">
                    <div class="mui-col-xs-3">xs-6</div>
                    <div class="mui-col-xs-3">xs-6</div>
                    <div class="mui-col-xs-3">xs-6</div>
                    <div class="mui-col-xs-3">xs-6</div>
                </div>
            </div>
        </div>
    </div>
    <?php wp_footer(); ?>
</body>
</html>